package com.srltcp.inclinometer;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity implements SensorEventListener {

    private static final String PREFS = "calibration";
    // Low-pass smoothing factor for the raw accelerometer (0..1, lower = smoother).
    private static final float ALPHA = 0.15f;

    private SensorManager sensorManager;
    private Sensor sensor;
    private InclinometerView view;
    private Button holdButton;

    private final float[] g = new float[3];
    private boolean haveReading;
    private boolean held;

    // Calibration offsets in degrees.
    private float offX, offY, offAngle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (sensor == null) {
            sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        offX = p.getFloat("x", 0f);
        offY = p.getFloat("y", 0f);
        offAngle = p.getFloat("a", 0f);

        view = new InclinometerView(this);

        Button zero = makeButton("Calibrate");
        zero.setOnClickListener(v -> calibrate());
        zero.setOnLongClickListener(v -> {
            resetCalibration();
            return true;
        });

        holdButton = makeButton("Hold");
        holdButton.setOnClickListener(v -> {
            held = !held;
            holdButton.setText(held ? "Release" : "Hold");
            view.setHeld(held);
        });

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        int pad = dp(12);
        buttons.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams bp =
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bp.setMargins(pad / 2, 0, pad / 2, 0);
        buttons.addView(zero, bp);
        buttons.addView(holdButton, bp);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(InclinometerView.BG);
        root.addView(view, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(buttons, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        if (sensor == null) {
            view.setMessage("No accelerometer found on this device");
        }
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(18);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sensor != null) {
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (!haveReading) {
            System.arraycopy(e.values, 0, g, 0, 3);
            haveReading = true;
        } else {
            for (int i = 0; i < 3; i++) {
                g[i] += ALPHA * (e.values[i] - g[i]);
            }
        }
        if (!held) {
            update();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor s, int accuracy) {
    }

    /** Tilt of the screen plane around the device's Y axis (left/right), degrees. */
    private float rawX() {
        return (float) Math.toDegrees(Math.atan2(g[0], Math.hypot(g[1], g[2])));
    }

    /** Tilt of the screen plane around the device's X axis (top/bottom), degrees. */
    private float rawY() {
        return (float) Math.toDegrees(Math.atan2(g[1], Math.hypot(g[0], g[2])));
    }

    /** Rotation around the screen normal, for when the phone stands on an edge. */
    private float rawAngle() {
        return (float) Math.toDegrees(Math.atan2(g[0], g[1]));
    }

    /** Lying flat when gravity is mostly along Z (screen within ~45° of horizontal). */
    private boolean isFlat() {
        float n = (float) Math.sqrt(g[0] * g[0] + g[1] * g[1] + g[2] * g[2]);
        return n > 0 && Math.abs(g[2]) / n > 0.707f;
    }

    private void update() {
        if (!haveReading) {
            return;
        }
        view.setReading(isFlat(), rawX() - offX, rawY() - offY,
                wrap(rawAngle() - offAngle));
    }

    private static float wrap(float deg) {
        while (deg > 180f) deg -= 360f;
        while (deg <= -180f) deg += 360f;
        return deg;
    }

    private void calibrate() {
        if (!haveReading) {
            return;
        }
        String what;
        if (isFlat()) {
            offX = rawX();
            offY = rawY();
            what = "Flat calibration saved";
        } else {
            // Snap to the nearest edge (0/90/180/-90) so any side can be zeroed.
            float a = rawAngle();
            float nearest = Math.round(a / 90f) * 90f;
            offAngle = a - nearest;
            what = "Edge calibration saved";
        }
        save();
        if (!held) {
            update();
        }
        Toast.makeText(this, what + " (long-press to reset)", Toast.LENGTH_SHORT).show();
    }

    private void resetCalibration() {
        offX = offY = offAngle = 0f;
        save();
        if (!held) {
            update();
        }
        Toast.makeText(this, "Calibration reset", Toast.LENGTH_SHORT).show();
    }

    private void save() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putFloat("x", offX)
                .putFloat("y", offY)
                .putFloat("a", offAngle)
                .apply();
    }
}
