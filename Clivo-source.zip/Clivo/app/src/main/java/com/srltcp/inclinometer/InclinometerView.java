package com.srltcp.inclinometer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;

/** Draws a bubble level when flat, and a rotating angle gauge when on an edge. */
public class InclinometerView extends View {

    static final int BG = Color.rgb(18, 24, 30);
    private static final int ACCENT = Color.rgb(77, 208, 225);
    private static final int LEVEL = Color.rgb(124, 252, 0);
    private static final int OFF = Color.rgb(255, 167, 38);
    // Readings within this many degrees count as level.
    private static final float LEVEL_TOLERANCE = 0.5f;
    // Tilt that pushes the bubble to the edge of the outer ring.
    private static final float MAX_TILT = 20f;

    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;

    private boolean hasReading;
    private boolean flat = true;
    private float tiltX, tiltY, angle;
    private boolean held;
    private String message;

    public InclinometerView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2 * density);
        big.setColor(Color.WHITE);
        big.setTextAlign(Paint.Align.CENTER);
        big.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        small.setColor(Color.LTGRAY);
        small.setTextAlign(Paint.Align.CENTER);
        small.setTextSize(16 * density);
    }

    void setReading(boolean flat, float tiltX, float tiltY, float angle) {
        this.flat = flat;
        this.tiltX = tiltX;
        this.tiltY = tiltY;
        this.angle = angle;
        hasReading = true;
        invalidate();
    }

    void setHeld(boolean held) {
        this.held = held;
        invalidate();
    }

    void setMessage(String message) {
        this.message = message;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(BG);
        float w = getWidth(), h = getHeight();
        if (message != null) {
            canvas.drawText(message, w / 2, h / 2, small);
            return;
        }
        if (!hasReading) {
            canvas.drawText("Waiting for sensor…", w / 2, h / 2, small);
            return;
        }
        if (flat) {
            drawBubble(canvas, w, h);
        } else {
            drawEdge(canvas, w, h);
        }
        if (held) {
            small.setColor(OFF);
            canvas.drawText("HOLD", w / 2, 28 * density, small);
            small.setColor(Color.LTGRAY);
        }
    }

    private void drawBubble(Canvas canvas, float w, float h) {
        float cx = w / 2, cy = h * 0.42f;
        float r = Math.min(w, h * 0.75f) * 0.42f;

        line.setColor(Color.GRAY);
        canvas.drawCircle(cx, cy, r, line);
        canvas.drawCircle(cx, cy, r * 0.5f, line);
        canvas.drawLine(cx - r, cy, cx + r, cy, line);
        canvas.drawLine(cx, cy - r, cx, cy + r, line);

        boolean level = Math.abs(tiltX) < LEVEL_TOLERANCE && Math.abs(tiltY) < LEVEL_TOLERANCE;
        float bubbleR = r * 0.14f;
        line.setColor(level ? LEVEL : ACCENT);
        canvas.drawCircle(cx, cy, bubbleR * 1.15f, line);

        // The bubble floats toward the raised side.
        float bx = tiltX / MAX_TILT * r;
        float by = -tiltY / MAX_TILT * r;
        float d = (float) Math.hypot(bx, by);
        float maxD = r - bubbleR;
        if (d > maxD) {
            bx *= maxD / d;
            by *= maxD / d;
        }
        fill.setColor(level ? LEVEL : OFF);
        canvas.drawCircle(cx + bx, cy + by, bubbleR, fill);

        float textY = cy + r + 70 * density;
        big.setTextSize(34 * density);
        big.setColor(Color.WHITE);
        canvas.drawText(String.format(Locale.US, "X %+5.1f°   Y %+5.1f°", tiltX, tiltY),
                cx, textY, big);
        // sin(X) and sin(Y) are the gravity components along the screen axes,
        // so together they give the angle between the screen and level.
        double sx = Math.sin(Math.toRadians(tiltX)), sy = Math.sin(Math.toRadians(tiltY));
        float total = (float) Math.toDegrees(Math.asin(Math.min(1.0, Math.hypot(sx, sy))));
        canvas.drawText(String.format(Locale.US, "Tilt %.1f°", total),
                cx, textY + 30 * density, small);
        canvas.drawText("Lay flat on a surface • stand on an edge for angles",
                cx, h - 16 * density, small);
    }

    private void drawEdge(Canvas canvas, float w, float h) {
        float cx = w / 2, cy = h * 0.42f;
        float r = Math.min(w, h * 0.75f) * 0.42f;

        // Deviation from the nearest horizontal/vertical, which is what a level shows.
        float nearest = Math.round(angle / 90f) * 90f;
        float dev = angle - nearest;
        boolean level = Math.abs(dev) < LEVEL_TOLERANCE;

        line.setColor(Color.GRAY);
        canvas.drawCircle(cx, cy, r, line);
        for (int deg = 0; deg < 360; deg += 15) {
            double a = Math.toRadians(deg);
            float in = deg % 90 == 0 ? r * 0.85f : r * 0.93f;
            canvas.drawLine(cx + (float) Math.cos(a) * in, cy + (float) Math.sin(a) * in,
                    cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, line);
        }

        // A plumb line: always points at true horizontal in the world.
        canvas.save();
        canvas.rotate(angle, cx, cy);
        line.setColor(level ? LEVEL : OFF);
        line.setStrokeWidth(4 * density);
        canvas.drawLine(cx - r * 0.95f, cy, cx + r * 0.95f, cy, line);
        line.setStrokeWidth(2 * density);
        canvas.restore();

        float textY = cy + r + 70 * density;
        big.setTextSize(56 * density);
        big.setColor(level ? LEVEL : Color.WHITE);
        canvas.drawText(String.format(Locale.US, "%.1f°", Math.abs(dev)), cx, textY, big);
        canvas.drawText(String.format(Locale.US, "Rotation %+.1f°", angle),
                cx, textY + 30 * density, small);
        canvas.drawText("Hold the phone's edge against the surface",
                cx, h - 16 * density, small);
    }
}
